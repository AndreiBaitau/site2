<?php
// Error
$_['error_extension'] = 'Warning: Payment method extension could not be found!';
$_['error_recurring'] = 'Warning: Payment method does not have recurring payment method!';
$_['error_payment']   = 'Warning: Payment method %s could not be found!';